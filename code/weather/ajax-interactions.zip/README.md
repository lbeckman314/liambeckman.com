My files include `ajax-interactions.html`, `ajax-interactions.js`, and `assets/main.css`.

Eveything else comes from [leaflet](https://leafletjs.com/) copyright Vladimir Agafonkin.

`images` includes png assets for leaflet.
